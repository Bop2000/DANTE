import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import pearsonr
from sklearn import metrics

all_value_all=[]
for n in range(5):
    all_R2=[]
    all_MAPE=[]
    all_data=pd.read_csv(f'model_performance_100d_{n}.csv')
    for i in range(1,(len(np.array(all_data)[0])+1) // 3):
        gt = np.array(all_data[f'{i}ground truth'].dropna())
        pred = np.array(all_data[f'{i}pred'].dropna())
        R=pearsonr(pred.reshape(-1), gt.reshape(-1))[0]
        R2 =R ** 2
        MAPE= metrics.mean_absolute_percentage_error(gt.reshape(-1), pred.reshape(-1))
        all_R2.append(R2)
        all_MAPE.append(MAPE)
    all_value_all.append(np.array(all_R2))
all_value_all=pd.DataFrame(all_value_all)
all_value_all=pd.DataFrame(all_value_all.T)
all_value_all=all_value_all.fillna(0)
mean=np.mean(all_value_all,axis=1)
std=np.std(all_value_all,axis=1)



plt.figure()
plt.plot(np.arange(len(mean)), mean, '-')
plt.fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)















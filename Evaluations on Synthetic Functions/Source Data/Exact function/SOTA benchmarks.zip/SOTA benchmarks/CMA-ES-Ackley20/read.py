import os
import numpy as np

f = open('result')
yourList = f.readlines()
yourList2=[]
max_len = 0
for i in yourList:
    i=i.strip('[')
    i=i.strip(']\n')
    # i=i.split(',')
    i = [item.strip() for item in i.split(',')]
    yourList2.append(i)
    if len(i) > max_len:
        max_len = len(i)
yourList3 = []
for i in yourList2:
    ii = np.array(i).astype(float)
    if len(ii) < max_len:
        ii = np.concatenate((ii, np.zeros(max_len-len(ii))))
    yourList3.append(ii)
yourList3 = np.array(yourList3)
mean = np.mean(yourList3, axis=0)
std = np.std(yourList3, axis=0)
print(len(yourList2))
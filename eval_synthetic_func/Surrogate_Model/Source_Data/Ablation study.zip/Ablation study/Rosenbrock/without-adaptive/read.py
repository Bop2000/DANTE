import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
n = 9
all_input=np.load(f'input100d_{n}.npy',allow_pickle=True)
all_data=np.load(f'data100d_{n}.npy',allow_pickle=True)

all_r2 =  pd.read_csv(f'model_performance_100d_{n}.csv')
print(min(all_data))
print((len(all_data)-200)/21)
print(len(np.array(all_r2)[0])/3)
plt.figure()
plt.plot(all_data)
plt.yscale('log')
all_input2 = np.unique(all_input,axis = 0)






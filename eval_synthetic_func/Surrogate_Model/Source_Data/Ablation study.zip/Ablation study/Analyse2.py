import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def process(f, label, d, sample_num):
    all_value_all=[]
    convergence_num = 0
    for n in range(5):
        all_value=[] 
        all_data=np.load(f'./{f}/{label}/data{d}d_{n}.npy')
        if round(min(all_data),5) == 0:
            convergence_num += 1
        data0=min(all_data[0:200])
        all_value.append(data0)
        for n in range(round(len(all_data[200:])/sample_num)):
            for m in range(sample_num):
                if min(all_data[200+n*sample_num:200+n*sample_num+sample_num])<data0:
                    all_value.append(min(all_data[200+n*sample_num:200+n*sample_num+sample_num]))
                    data0=min(all_data[200+n*sample_num:200+n*sample_num+sample_num])
                else:
                    all_value.append(data0)       
        if f == 'Rosenbrock' and d == 100 and len(all_value) < 10501:
            for i in range(10501 - len(all_value)):
                all_value.append(min(all_value))
        all_value_all.append(all_value)
    all_value_all=pd.DataFrame(all_value_all)
    all_value_all=pd.DataFrame(all_value_all.T)
    all_value_all=all_value_all.fillna(0)
    mean=np.mean(all_value_all,axis=1)
    std=np.std(all_value_all,axis=1)
    print(label,f,d,convergence_num)
    return mean, std


def process1(f, label, d):
    datas = []
    for n in range(5):
        data=np.load(f'./{f}/{label}/data{d}d_{n}.npy')
        datas.append(data)
    all_value_all=pd.DataFrame(datas)
    all_value_all=pd.DataFrame(all_value_all.T)
    all_value_all=all_value_all.fillna(0)
    mean=np.mean(all_value_all,axis=1)
    std=np.std(all_value_all,axis=1)
    return mean, std

labels1 = ['Without visit sampling',      'Without adaptive exploration weight',    'Without backpropagation (DOTS-Greedy)','DOTS']
labels2 = ['without-visit',      'without-adaptive',    'without-backpropagation',       'DOTS'         ]
colors  = ["#69B77F","#F0AC42","#5DC6DD",'#ED6F6A']

funcs = ['Ackley', 'Rastrigin', 'Rosenbrock']

fig, ax = plt.subplots(3, 3, figsize=(12, 10), dpi=300)
for i, l in enumerate(labels1):
    for j, f in enumerate(funcs):
        if f == 'Rosenbrock':
            dims = [20, 60, 100]
            sample_num = 21
        elif f == 'Ackley':
            dims = [20, 100, 200]
            sample_num = 20
        elif f == 'Rastrigin':
            dims = [20, 100, 1000]
            sample_num = 20
        else:
            dims = [20, 100, 1000]
            sample_num = 20
        
        for k, d in enumerate(dims):
            try:
                if l == 'TuRBO5':
                    mean, std = process1(f, labels2[i], d)
                elif l == 'LAMCTS':
                    mean, std = process1(f, labels2[i], d)
                else:
                    mean, std = process(f, labels2[i], d, sample_num)
                
                if j == 0 and k == 1:
                    mean, std = mean[:2801], std[:2801]
                elif j == 0 and k == 2:
                    mean, std = mean[:4401], std[:4401]
                elif j == 2 and k == 0:
                    mean, std = mean[:6301], std[:6301]
                elif j == 2 and k == 1:
                    mean, std = mean[:10501], std[:10501]
                elif j == 2 and k == 2:
                    mean, std = mean[:10501], std[:10501]

                
                ax[j, k].plot(np.arange(len(mean)), mean, '-', label = l, color = colors[i])
                ax[j, k].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2, facecolor=colors[i])
            except:
                print(f'{l}_{f}_{d}d, pass')

for x, n in enumerate(funcs):
    if n == 'Rosenbrock':
        dims = [20, 60, 100]
    elif n == 'Ackley':
        dims = [20, 100, 200]
    else:
        dims = [20, 100, 1000]
    for y, m in enumerate(dims):
        ax[x, y].set_xlabel('#samples')
        ax[x, y].set_ylabel('f(x)')
        ax[x, y].set_title(n +'-'+str(m)+'d')



ax[0, 0].legend(prop={'size':8})
ax[2, 0].set_yscale('log')
ax[2, 1].set_yscale('log')
ax[2, 2].set_yscale('log')
ax[2, 0].set_ylim((1,2e5))
ax[2, 1].set_ylim((1,1e6))
ax[2, 2].set_ylim((10,2e6))
plt.tight_layout()
plt.savefig('./test.png')














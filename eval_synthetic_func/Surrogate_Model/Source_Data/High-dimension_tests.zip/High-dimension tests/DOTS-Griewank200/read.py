import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


all_data=np.load('result.npy',allow_pickle=True)
plt.plot(all_data,linewidth=5)
# plt.yscale('log')
plt.legend()
print(min(all_data))
#
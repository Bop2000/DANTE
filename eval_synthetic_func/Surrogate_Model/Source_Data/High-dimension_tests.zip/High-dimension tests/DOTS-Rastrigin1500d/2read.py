import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

n_dim=1000
sample_num = 20
list1 = [1,2,3,4,5]

def data_process(datas):
    all_value_all=[]
    for i in range(len(datas)):
        all_value=[]
        all_data=datas[i]
        data0=min(all_data[0:200])
        all_value.append(data0)
        for n in range(round(len(all_data[200:])/sample_num)):
            for m in range(sample_num):
                if min(all_data[200+n*sample_num:200+n*sample_num+sample_num])<data0:
                    all_value.append(min(all_data[200+n*sample_num:200+n*sample_num+sample_num]))
                    data0=min(all_data[200+n*sample_num:200+n*sample_num+sample_num])
                else:
                    all_value.append(data0)        
        all_value_all.append(all_value)
    all_value_all=pd.DataFrame(all_value_all)
    all_value_all=pd.DataFrame(all_value_all.T)
    all_value_all=all_value_all.fillna(0)
    all_value_mean=np.mean(all_value_all,axis=1)
    all_value_std=np.std(all_value_all,axis=1)
    all_value_all=pd.concat((all_value_all,pd.DataFrame(all_value_mean),pd.DataFrame(all_value_std)),axis=1)
    return all_value_all

def process(all_data):
    cu_y=min(all_data[:200])
    all_data2=[cu_y]
    for i in all_data[200:]:
        if i < cu_y:
            cu_y=i
        all_data2.append(cu_y)
    return all_data2

datas = []
plt.figure()
for i in list1:
    all_data=np.load(f'result{i}.npy',allow_pickle=True)
    all_data2=process(all_data)
    plt.plot(all_data2,label=i,linewidth=5)
    datas.append(all_data)
plt.legend()

############################
all_value_all = data_process(datas)
all_value_all = np.array(all_value_all)
x = np.arange(len(all_value_all[:,-1]))
y = all_value_all[:,-2]
error = all_value_all[:,-1]

plt.figure()
plt.plot(x, y, 'k', color='#CC4F1B')
plt.fill_between(x, y-error, y+error,
    alpha=0.2, edgecolor='#CC4F1B', facecolor='#FF9848')


# plt.figure()
# plt.plot(x, y, 'k', color='#1B2ACC')
# plt.fill_between(x, y-error, y+error,
#     alpha=0.2, edgecolor='#1B2ACC', facecolor='#089FFF',
#     linewidth=4, linestyle='dashdot', antialiased=True)


# plt.figure()
# plt.plot(x, y, 'k', color='#3F7F4C')
# plt.fill_between(x, y-error, y+error,
#     alpha=1, edgecolor='#3F7F4C', facecolor='#7EFF99',
#     linewidth=0)

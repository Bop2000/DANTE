import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


list1 = [0]

def process(all_data):
    cu_y=min(all_data[:200])
    all_data2=[cu_y]
    for i in all_data[200:]:
        if i < cu_y:
            cu_y=i
        all_data2.append(cu_y)
    return all_data2


datas = []
plt.figure()
for i in list1:
    all_data=np.load('result.npy',allow_pickle=True)
    all_data2=process(all_data)
    plt.plot(all_data2,label=i,linewidth=5)
    datas.append(all_data)
    print(min(all_data2))
# plt.yscale('log')
plt.legend()





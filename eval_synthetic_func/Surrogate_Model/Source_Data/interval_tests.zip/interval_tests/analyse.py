import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def process(name, sample_num=20):
    all_value_all=[]
    convergence_num = 0
    samples = []
    for n in range(1,6):
        all_value=[]
        all_data=np.load(f'./{name}/result{n}.npy')
        if round(min(all_data),5) == 0:
            convergence_num += 1
        
        try:
            ind = np.where(all_data < 0.01)[0]
            samples.append(min(ind)+1)
        except:
            samples.append(len(all_data))
        
        data0=min(all_data[0:200])
        all_value.append(data0)
        for n in range(round(len(all_data[200:])/sample_num)):
            for m in range(sample_num):
                if min(all_data[200+n*sample_num:200+n*sample_num+sample_num])<data0:
                    all_value.append(min(all_data[200+n*sample_num:200+n*sample_num+sample_num]))
                    data0=min(all_data[200+n*sample_num:200+n*sample_num+sample_num])
                else:
                    all_value.append(data0)        
        all_value_all.append(all_value)
    all_value_all=pd.DataFrame(all_value_all)
    all_value_all=pd.DataFrame(all_value_all.T)
    all_value_all=all_value_all.fillna(0)
    mean=np.mean(all_value_all,axis=1)
    std=np.std(all_value_all,axis=1)
    print(name,convergence_num)
    # print('cmean',np.mean(samples),'cstd',np.std(samples),'min',min(samples))
    return mean, std

labels = ['interval0.01', 'interval0.1']
labels2 = ['0.01', '0.1']
funcs = ['Ackley', 'Rastrigin']

fig, ax = plt.subplots(3, 1, figsize=(3.8, 10), dpi=300)
for l,i in enumerate(labels):
    try:
        mean, std = process(i + '/DOTS-Ackley20')
        ax[0].plot(np.arange(len(mean)), mean, '-', label = labels2[l])
        ax[0].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
        ax[0].set_title('Ackley-20d')
    except:
        pass
    
    try:
        mean, std = process(i + '/DOTS-Ackley100')
        ax[1].plot(np.arange(len(mean)), mean, '-', label = labels2[l])
        ax[1].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
        ax[1].set_title('Ackley-100d')
    except:
        pass
    
    try:
        mean, std = process(i + '/DOTS-Rastrigin20')
        ax[2].plot(np.arange(len(mean)), mean, '-', label = labels2[l])
        ax[2].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
        ax[2].set_title('Rastrigin-20d')
    except:
        pass







# fig, ax = plt.subplots(2, 2, figsize=(8, 7), dpi=300)
# for l,i in enumerate(labels):
#     for x, n in enumerate(funcs):
#         dims = [20, 100]
#         for y, m in enumerate(dims):
#             try:
#                 mean, std = process(i + '/DOTS-' + n + str(m))
#                 ax[x, y].plot(np.arange(len(mean)), mean, '-', label = labels2[l])
#                 ax[x, y].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
#             except:
#                 pass


for i in range(3):
    ax[i].set_xlabel('#samples')
    ax[i].set_ylabel('f(x)')



ax[0].legend()
# ax[2, 0].set_yscale('log')
# ax[2, 1].set_yscale('log')
# # ax[2, 2].set_yscale('log')
plt.tight_layout()
plt.savefig('./test.png')




# fig, ax = plt.subplots(3, 2, figsize=(4, 5), dpi=300)
# for l,i in enumerate(labels):
#     for x, n in enumerate(funcs):
#         dims = [20, 100]
#         for y, m in enumerate(dims):
#             try:
#                 mean, std = process(i + '/DOTS-' + n + str(m))
#                 ax[x, y].plot(np.arange(len(mean)), mean, '-', label = labels2[l])
#                 ax[x, y].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
#             except:
#                 pass

# # ax[2, 0].set_yscale('log')
# # ax[2, 1].set_yscale('log')

# ax[0, 0].set_ylim((-0.05,0.5))
# ax[0, 1].set_ylim((-0.05,0.5))

# ax[1, 0].set_ylim((-0.5,5))
# ax[1, 1].set_ylim((-1,10))

# # ax[0, 0].set_xlim((80,350))
# # ax[0, 1].set_xlim((300,650))

# # ax[1, 0].set_xlim((0,2100))
# # ax[1, 1].set_xlim((250,3150))

# plt.tight_layout()
# plt.savefig('./test-inset.png')












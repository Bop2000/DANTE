import numpy as np
import matplotlib.pyplot as plt


# all_input=np.load('input100d_2.npy',allow_pickle=True)
all_data=np.load('result1.npy',allow_pickle=True)

print(min(all_data))

# plt.figure()
plt.plot(all_data)
# plt.yscale('log')
# np.save('result1.npy',all_data[:7340],allow_pickle=True)




import os
import numpy as np
import matplotlib.pyplot as plt

def process(name):
    f = open(name+'/result')
    yourList = f.readlines()
    yourList2=[]
    max_len = 0
    for i in yourList:
        i=i.strip('[')
        i=i.strip(']\n')
        # i=i.split(',')
        i = [item.strip() for item in i.split(',')]
        yourList2.append(i)
        if len(i) > max_len:
            max_len = len(i)
    yourList3 = []
    for i in yourList2:
        ii = np.array(i).astype(float)
        if len(ii) < max_len:
            ii = np.concatenate((ii, np.zeros(max_len-len(ii))))
        yourList3.append(ii)
    yourList3 = np.array(yourList3)
    mean = np.mean(yourList3, axis=0)
    std = np.std(yourList3, axis=0)
    print(name,len(yourList3))
    return mean, std

labels = ['0','0.01', '0.1','1','10','100']
funcs = ['Ackley', 'Rastrigin', 'Rosenbrock']

fig, ax = plt.subplots(3, 3, figsize=(6, 5), dpi=300)
for i in labels:
    for x, n in enumerate(funcs):
        if n == 'Rosenbrock':
            dims = [20, 60, 100]
        else:
            dims = [20, 100, 1000]
        for y, m in enumerate(dims):
            try:
                mean, std = process('ratio' + i + '/' + n + str(m))
                ax[x, y].plot(np.arange(len(mean)), mean, '-', label = i)
                ax[x, y].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
            except:
                pass

# mean, std = process('MCMC-Ackley20')
# ax[0, 0].plot(np.arange(len(mean)), mean, '-', label='MCMC')
# ax[0, 0].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
# ax[0, 0].set_xlabel('#samples')
# ax[0, 0].set_ylabel('f(x)')
# ax[0, 0].set_title('Ackley-20d')


# for x, n in enumerate(funcs):
#     if n == 'Rosenbrock':
#         dims = [20, 60, 100]
#     else:
#         dims = [20, 100, 1000]
#     for y, m in enumerate(dims):
#         ax[x, y].set_xlabel('#samples')
#         ax[x, y].set_ylabel('f(x)')
#         ax[x, y].set_title(n +'-'+str(m)+'d')



# ax[0, 0].legend()
ax[2, 0].set_yscale('log')
ax[2, 1].set_yscale('log')
ax[2, 2].set_yscale('log')
ax[0, 0].set_ylim((-0.05,0.5))
ax[0, 1].set_ylim((-0.05,0.5))
ax[0, 2].set_ylim((-0.05,0.5))
ax[1, 0].set_ylim((-1,10))
ax[1, 1].set_ylim((-3,30))
ax[1, 2].set_ylim((-5,50))
ax[0, 0].set_xlim((80,350))
ax[0, 1].set_xlim((300,650))
ax[0, 2].set_xlim((2000,3200))
ax[1, 0].set_xlim((0,2100))
ax[1, 1].set_xlim((250,3150))
ax[1, 2].set_xlim((2500,10500))
# ax[0, 0].set_xticks(fontsize=20)

plt.tight_layout()
plt.savefig('./test-inset.png')














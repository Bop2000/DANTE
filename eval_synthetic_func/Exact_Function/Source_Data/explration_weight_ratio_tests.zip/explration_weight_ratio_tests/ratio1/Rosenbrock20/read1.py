import os
import numpy as np
import matplotlib.pyplot as plt

f = open('result2')
yourList = f.readlines()
yourList2=[]
max_len = 0
for i in yourList:
    i=i.strip('[')
    i=i.strip(']\n')
    # i=i.split(',')
    i = [item.strip() for item in i.split(',')]
    yourList2.append(i)
    if len(i) > max_len:
        max_len = len(i)
yourList3 = []
plt.figure()
for x, i in enumerate(yourList2):
    ii = np.array(i).astype(float)
    plt.plot(ii,label=x,linewidth=5)
    if len(ii) < max_len:
        ii = np.concatenate((ii, np.zeros(max_len-len(ii))))
    yourList3.append(ii)
yourList3 = np.array(yourList3)
mean = np.mean(yourList3, axis=0)
std = np.std(yourList3, axis=0)
plt.legend()
plt.yscale('log')

plt.figure()
plt.plot(np.arange(len(mean)), mean, '-', label = i)
plt.fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
plt.yscale('log')













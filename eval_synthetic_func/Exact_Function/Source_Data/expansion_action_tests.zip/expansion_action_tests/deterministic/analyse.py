import os
import numpy as np
import matplotlib.pyplot as plt

def process(name):
    f = open(name+'/result')
    yourList = f.readlines()
    yourList2=[]
    max_len = 0
    for i in yourList:
        i=i.strip('[')
        i=i.strip(']\n')
        # i=i.split(',')
        i = [item.strip() for item in i.split(',')]
        yourList2.append(i)
        if len(i) > max_len:
            max_len = len(i)
    yourList3 = []
    for i in yourList2:
        ii = np.array(i).astype(float)
        if len(ii) < max_len:
            ii = np.concatenate((ii, np.zeros(max_len-len(ii))))
        yourList3.append(ii)
    yourList3 = np.array(yourList3)
    mean = np.mean(yourList3, axis=0)
    std = np.std(yourList3, axis=0)
    print(name,len(yourList3))
    return mean, std

labels = ['DOTS-Greedy','DOTS-eGreedy','DOTS']
funcs = ['Ackley', 'Rastrigin', 'Rosenbrock']
labels1 = ['DOTS-Greedy','DOTS-eGreedy','DOTS']
colors  = ["#F0AC42","#5DC6DD",'#ED6F6A']


fig, ax = plt.subplots(3, 3, figsize=(12, 10), dpi=300)
for l,i in enumerate(labels):
    for x, n in enumerate(funcs):
        if n == 'Rosenbrock':
            dims = [20, 60, 100]
        else:
            dims = [20, 100, 1000]
        for y, m in enumerate(dims):
            try:
                mean, std = process(i + '-' + n + str(m))
                ax[x, y].plot(np.arange(len(mean)), mean, '-', label = labels1[l], color = colors[l])
                ax[x, y].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2, facecolor=colors[l])
            except:
                pass

for x, n in enumerate(funcs):
    if n == 'Rosenbrock':
        dims = [20, 60, 100]
    else:
        dims = [20, 100, 1000]
    for y, m in enumerate(dims):
        ax[x, y].set_xlabel('#samples')
        ax[x, y].set_ylabel('f(x)')
        ax[x, y].set_title(n +'-'+str(m)+'d')



ax[0, 0].legend()
ax[2, 0].set_yscale('log')
ax[2, 1].set_yscale('log')
ax[2, 2].set_yscale('log')
plt.tight_layout()
plt.savefig('./test3.png')














import os
import numpy as np
import matplotlib.pyplot as plt

def process(name):
    f = open(name+'/result')
    yourList = f.readlines()
    yourList2=[]
    max_len = 0
    for i in yourList:
        i=i.strip('[')
        i=i.strip(']\n')
        # i=i.split(',')
        i = [item.strip() for item in i.split(',')]
        yourList2.append(i)
        if len(i) > max_len:
            max_len = len(i)
    yourList3 = []
    for i in yourList2:
        ii = np.array(i).astype(float)
        if len(ii) < max_len:
            ii = np.concatenate((ii, np.zeros(max_len-len(ii))))
        yourList3.append(ii)
    yourList3 = np.array(yourList3)
    mean = np.mean(yourList3, axis=0)
    std = np.std(yourList3, axis=0)
    print(name,len(yourList2))
    return mean, std

labels = ['DOTS']
funcs = ['Ackley', 'Rastrigin', 'Rosenbrock','Schwefel','Griewank','Michalewicz','Levy']

fig, ax = plt.subplots(7, 3, figsize=(12, 24), dpi=300)
for i in labels:
    for x, n in enumerate(funcs):
        if n == 'Rosenbrock' or n == 'Michalewicz':
            dims = [200, 300, 500]
        elif n == 'Schwefel':
            dims = [1200, 1300, 1500]
        elif n == 'Ackley':
            dims = [3000, 5000,10000]
        elif n == 'Levy':
            dims = [1000, 3000,5000]
        else:
            dims = [2000, 3000,5000]
        for y, m in enumerate(dims):
            try:
                mean, std = process(i + '-' + n + str(m))
                ax[x, y].plot(np.arange(len(mean)), mean, '-', label = i)
                ax[x, y].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
            except:
                pass

# mean, std = process('MCMC-Ackley20')
# ax[0, 0].plot(np.arange(len(mean)), mean, '-', label='MCMC')
# ax[0, 0].fill_between(np.arange(len(mean)), mean -std, mean + std, alpha=0.2)
# ax[0, 0].set_xlabel('#samples')
# ax[0, 0].set_ylabel('f(x)')
# ax[0, 0].set_title('Ackley-20d')


for x, n in enumerate(funcs):
    if n == 'Rosenbrock' or n == 'Michalewicz':
        dims = [200, 300, 500]
    elif n == 'Schwefel':
        dims = [1200, 1300, 1500]
    elif n == 'Ackley':
        dims = [3000, 5000,10000]
    elif n == 'Levy':
        dims = [1000, 3000,5000]
    else:
        dims = [2000, 3000,5000]
    for y, m in enumerate(dims):
        ax[x, y].set_xlabel('#samples')
        ax[x, y].set_ylabel('f(x)')
        ax[x, y].set_title(n +'-'+str(m)+'d')



# ax[0, 0].legend()
ax[2, 0].set_yscale('log')
ax[2, 1].set_yscale('log')
ax[2, 2].set_yscale('log')
plt.tight_layout()
plt.savefig('./test3.png')













